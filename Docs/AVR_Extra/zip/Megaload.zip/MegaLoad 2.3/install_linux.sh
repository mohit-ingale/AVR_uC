#! /bin/bash

cp ./megaload /sbin/
cp ./MegaLoad.exe /sbin.
